package edu.many.quiz;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Manel on 13/12/17.
 */
public class Singleton {
    private static Singleton mInstance = null;
    private int numAciertos;
    private int numFallos;
    private int whichQuestion;
    private static ArrayList<String> questions = new ArrayList<String>(Arrays.asList(
            "¿De qué color es el caballo blanco de Santiago?",
            "¿Cuantos años tiene un lustro?",
            "¿Cual es una verdura?"
    ));
    private static ArrayList<String> answers = new ArrayList<String>(Arrays.asList(
            "Verde",
            "Blanco",
            "Rojo",
            "1",
            "2",
            "5",
            "Lechuga",
            "Hamburguesa",
            "Ordenador"
    ));
    private int[] correctAnswers = {1,2,0};


    public Singleton(){

    }

    public static  Singleton getInstace(){
        if(mInstance == null){
            mInstance = new Singleton();
        }
        return mInstance;
    }

    public int getNumAciertos(){
        return this.numAciertos;
    }

    public int getNumFallos(){
        return this.numFallos;
    }

    public void incAciertos(){
        this.numAciertos++;
    }

    public void incFallos(){
        this.numFallos++;
    }

    public void incQuestion(){
        this.whichQuestion++;
    }

    public String getQuestion(int i){
        return this.questions.get(i);
    }

    public int sizeQuestions(){
        return this.questions.size();
    }

    public String getAnswers(int i){
        return this.answers.get(3 * whichQuestion + i);
    }

    public int getRightAnswer(int question){
        return this.correctAnswers[question];
    }

    public void startQuiz(){
        this.numAciertos = 0;
        this.numFallos = 0;
        this.whichQuestion = 0;
    }

    public int askQuestion(){
        return this.whichQuestion;
    }
}