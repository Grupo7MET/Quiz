package edu.many.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class FinalActivity extends AppCompatActivity {

    private TextView tvRight;
    private TextView tvWrong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        tvRight = (TextView) findViewById(R.id.tvRight);
        tvWrong = (TextView) findViewById(R.id.tvWrong);

        tvRight.setText(tvRight.getText() + String.valueOf(Singleton.getInstace().getNumAciertos()));
        tvWrong.setText(tvWrong.getText() + String.valueOf(Singleton.getInstace().getNumFallos()));

    }

    public void Restart(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
        finish();
    }
}
