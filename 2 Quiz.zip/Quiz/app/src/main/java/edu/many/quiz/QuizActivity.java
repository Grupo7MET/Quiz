package edu.many.quiz;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class QuizActivity extends AppCompatActivity {

    private RadioGroup rg1;
    private TextView tv1;
    private TextView tvIndex;
    private Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        rg1 = (RadioGroup) findViewById(R.id.rg1);
        tv1 = (TextView) findViewById(R.id.tv1);
        tvIndex = (TextView) findViewById(R.id.tvIndex);
        b1 = (Button) findViewById(R.id.b1);

        //Se empieza escribiendo la pregunta y respuestas
        tv1.setText(Singleton.getInstace().getQuestion(Singleton.getInstace().askQuestion()));
        ((RadioButton) rg1.getChildAt(0)).setText(Singleton.getInstace().getAnswers(0));
        ((RadioButton) rg1.getChildAt(1)).setText(Singleton.getInstace().getAnswers(1));
        ((RadioButton) rg1.getChildAt(2)).setText(Singleton.getInstace().getAnswers(2));
        tvIndex.setText(String.valueOf(Singleton.getInstace().askQuestion()+1) + " of " + String.valueOf(Singleton.getInstace().sizeQuestions()));

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Cogemos el indice seleccionado como respuesta
                int index = rg1.indexOfChild(findViewById(rg1.getCheckedRadioButtonId()));
                int right = Singleton.getInstace().getRightAnswer(Singleton.getInstace().askQuestion());
                if (index == right) {
                    Singleton.getInstace().incAciertos();
                } else {
                    Singleton.getInstace().incFallos();
                }
                if (Singleton.getInstace().askQuestion() < 2) {
                    Singleton.getInstace().incQuestion();
                    Intent intent = new Intent(getApplicationContext(), QuizActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(getApplicationContext(), FinalActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

            }
        });
    }
}
